package mainpackage.telecompackage;

public class Call {

	private String sendersPhoneNumber, recipientsPhoneNumber, callDuration, callDate, callStartTime;

    public Call(String spN, String rpN, String cD, String d, String t) {
    	this.sendersPhoneNumber = spN;
        this.recipientsPhoneNumber = rpN;
        this.callDuration = cD;
        this.callDate = d;
        this.callStartTime = t;
        System.out.println("Call Object has been created. Now you can access the details of a call");
    }
    
    public Call() {
    	//Default values
    	this.sendersPhoneNumber = "0000000000";
        this.recipientsPhoneNumber = "1111111111";
        this.callDuration = "0";
        this.callDate = "-";
        this.callStartTime = "-";
    	 System.out.println("Call Object has been created. Now you have to initialize the details of the call");
    }

    //Getters
    public String getSendersPhoneNumber() { return this.sendersPhoneNumber; }

    public String getRecipientsPhoneNumber() { return this.recipientsPhoneNumber; }

    public String getCallDuration() { return this.callDuration;  }

    public String getCallDate() { return this.callDate; }

    public String getCallStartTime() { return this.callStartTime; }

    //Setters
    public void setSendersPhoneNumber(String spN) { this.sendersPhoneNumber = spN; }

    public void setRecipientsPhoneNumber(String rpN) { this.recipientsPhoneNumber = rpN; }

    public void setCallDuration(String cD) { this.callDuration = cD; }

    public void setCallDate(String d) { this.callDate = d; }

    public void setCallStartTime(String t) { this.callStartTime = t; }

    public void viewCallDetails() {
        System.out.println("Call details: \n Sender: " + this.sendersPhoneNumber + 
        		"\n Recipient: " + this.recipientsPhoneNumber + "\n Call Duration: " + 
        		this.callDuration + "\n Call Date: " + this.callDate + "\n Call Start Time: " + this.callStartTime);
    }
}
