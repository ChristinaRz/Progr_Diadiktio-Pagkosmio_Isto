package mainpackage.telecompackage;

public class PhoneNumber {

	private String phoneNumber;
    private String program;

    public PhoneNumber(String phoneNumber, String program) {
        this.phoneNumber = phoneNumber;
        this.program = program;
        System.out.println("Phone-number and program connection!");
    }

    public PhoneNumber(){
    	//Default values
    	this.phoneNumber = "0000000000";
    	this.program= "Default Program Name";
        System.out.println("Phone-number and program connection!");
    }

    public String getPhoneNumber() { return phoneNumber; }
    
    public String getProgram() { return program; }

    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public void setProgram(String program) { this.program = program; }
}
