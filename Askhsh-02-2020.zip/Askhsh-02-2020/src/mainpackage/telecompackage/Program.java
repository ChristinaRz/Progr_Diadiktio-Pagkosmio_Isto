package mainpackage.telecompackage;

public class Program {

	private String programName, programPackage;
	private double programCost;

    public Program() {
        //Default values
        this.programName = "Default Program Name";
        this.programPackage = "Default Program Package";
        this.programCost = 0;
        System.out.println("New Program has been created!");
    }

    public Program(String programName, String programPackage, double programCost) {
        this.programName = programName;
        this.programPackage = programPackage;
        this.programCost = programCost;
        System.out.println("New Program has been created!");
    }

    //Getters
    public String getProgramName() { return programName; }

    public String getProgramPackage() { return programPackage; }

    public double getProgramCost() { return programCost; }

    //Setters
    public void setProgramName(String programName) { this.programName = programName; }

    public void setProgramPackage (String programPackage) { this.programPackage = programPackage; }

    public void setProgramCost(double programCost) { this.programCost = programCost; }

    //View current program
    public void ViewProgram(){
        System.out.println("Current program: \nProgram Name: " + this.programName + 
        		"\nProgram Package: " + this.programPackage + "\nProgram Cost: " + this.programCost);
    }
}
