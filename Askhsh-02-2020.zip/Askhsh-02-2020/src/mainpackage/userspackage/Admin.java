package mainpackage.userspackage;

import mainpackage.telecompackage.Program;

public class Admin extends Users {

	 private final String AFM;
	 private String phoneNumber;

	 public Admin(String afm){ //constructor
		 super(afm, Users.isAFMValid(afm), "admin");
		 if(Users.isAFMValid(afm)) {
			this.AFM = afm;
			System.out.println("Admin has been created successfully!");
		 } else {
			System.out.println("Wrong afm or afm already exists. Admin could not be created!");
			this.AFM = "000000000";
		 }
		 this.phoneNumber = "0000000000";
	 }

	 public String getAFM() {return this.AFM;}
	 
	 public String getPhoneNumber(){ return this.phoneNumber; }
  
	 public void setPhoneNumber(String phoneNumber) {
		if(Users.isTelValid(phoneNumber)) { this.phoneNumber = phoneNumber;}
		else { System.out.println("Wrong phone number format. Please try again!"); }
	 }

	 public void createUser(String username, String name, String surname, String password, String address, String email, String category) {
		 System.out.println("Users before:" + usersCounter);
		 if (category == "seller") { 
			 Seller s = new Seller("768594325");
			 s.setUsername(username); s.setName(name); s.setSurname(surname); s.setPassword(password);
			 s.setAddress(address); s.setEmail(email); s.setCategory(category);
			 System.out.println("Username: "+s.getUsername()+ "\nName: "+s.getName()+ "\nSurname: "+s.getSurname()+
					 "\nPassword: "+s.getPassword()+ "\nAddress: "+s.getAddress()+ "\nEmail: "+ s.getEmail()+ "\nCategory: " + s.getCategory());
		 }  
		 else if (category == "client") { 
	    	 Client c = new Client("574836524");
	    	 c.setUsername(username); c.setName(name); c.setSurname(surname); c.setPassword(password);
			 c.setAddress(address); c.setEmail(email); c.setCategory(category);
			 System.out.println("Username: "+c.getUsername()+ "\nName: "+c.getName()+ "\nSurname: "+c.getSurname()+
					 "\nPassword: "+c.getPassword()+ "\nAddress: "+c.getAddress()+ "\nEmail: "+ c.getEmail()+ "\nCategory: " + c.getCategory());
	     }
	     else if (category == "admin") { 
	    	 Admin a = new Admin("768574531");
	    	 a.setUsername(username); a.setName(name); a.setSurname(surname); a.setPassword(password);
			 a.setAddress(address); a.setEmail(email); a.setCategory(category);
			 System.out.println("Username: "+a.getUsername()+ "\nName: "+a.getName()+ "\nSurname: "+a.getSurname()+
					 "\nPassword: "+a.getPassword()+ "\nAddress: "+a.getAddress()+ "\nEmail: "+ a.getEmail()+ "\nCategory: " + a.getCategory());
	     }
	     System.out.println("Users now: " + usersCounter);
	  } 

	 public void updateUser(String afm, String category)
	 {
		 if (category == null) {System.out.println("User updated successfully");}
	     else if (category == "seller") {System.out.println("Seller updated successfully");}
	     else if (category == "client") {System.out.println("Client updated successfully");}
	     else if (category == "admin") {System.out.println("Admin updated successfully");}
	 }
	 
	 public void deleteUser(String afm, String category)
	 {
		 System.out.println("Users before: " + usersCounter);
		 usersCounter--;
		 System.out.println("Users now: " + usersCounter);
		 //Search for User with the afm given and then delete him.
		 if (category == null) {System.out.println("User deleted successfully");}
	     else if (category == "seller") {System.out.println("Seller deleted successfully");}
	     else if (category == "client") {System.out.println("Client deleted successfully");}
	     else if (category == "admin") {System.out.println("Admin deleted successfully");}
	 }

	 public void searchUser(String afm)
	 {
		 //Check if user with the given afm exists and if so then print the message.
		 System.out.println("Details of user with AFM: "+afm+ ":...");
	 }

	 //proboli stoixeiwn twn xrhstwn kai to xrostoumeno poso
	 public void viewUsers()
	 {
		System.out.println("List of users and the amount they owe!"); 
	 }

	 public void createNewProgram(String progName, String progPack, double progCost){
		 System.out.println("New program setted");
		 Program p = new Program();
		 p.setProgramName(progName);
	     p.setProgramPackage(progPack);
	     p.setProgramCost(progCost);
	     System.out.println("Success!\nProgram name: " + p.getProgramName() + "\nProgram package: " + p.getProgramPackage() + "\nProgram cost: " + p.getProgramCost());
	    }

	 public void menuAdmin(int choice)
	 {
		 System.out.println("Main menu");
	     try {
	    	 System.out.println("What you want to do: \n 1)Create User \n 2)Update User \n 3)Delete User \n 4)Search User \n 5)View Users \n 6)Create a new programm \n 7)Return to main menu ");
	    	 System.out.println(choice);
	    	 switch(choice){
	    	 	case 1: createUser("ClaudeB","Claude","Bolton","hduwncie@","Wilbur 7, Cannon Avenue","claudeBolton@gmail.com","client");
	                break;
	            case 2: updateUser("879675843","seller");
	                break;
	            case 3: deleteUser("768573549", "admin");
	                break;
	            case 4: searchUser("768564739");
	                break;
	            case 5: viewUsers();
	                break;
	            case 6: createNewProgram("COSMOTE Double Play 50 L","50 MBPS,120 ����� ����������", 32.90);
	                break;
	            //case 7: menuAdmin();
	                //break;
	         }
	     }
	     catch(ArithmeticException e) { System.out.println("Arithmetic Exception!"); }
	 }
	    
}
