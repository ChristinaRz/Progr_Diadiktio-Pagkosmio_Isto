package mainpackage.userspackage;

public class Client extends Users{

	private final String AFM;
    private String phoneNumber, property;

    public Client(String afm) {
    	super(afm, Users.isAFMValid(afm), "client");
		if(Users.isAFMValid(afm)) {
			this.AFM = afm;
			System.out.println("Client has been created successfully!");
		} else {
			System.out.println("Wrong afm or afm already exists. Client could not be created!");
			this.AFM = "000000000";
		}
		//Default values
        this.phoneNumber = "0000000000";
        this.property = "-";
    }

    public Client(String afm, String phoneNumber, String property) {
    	super(afm, Users.isAFMValid(afm), "client");
		if(Users.isAFMValid(afm)) {
			this.AFM = afm;
			System.out.println("Client has been created successfully!");
		} else {
			System.out.println("Wrong afm or afm already exists. Client could not be created!");
			this.AFM = "000000000";
		}
		if(Users.isTelValid(phoneNumber)) {
			this.phoneNumber = phoneNumber;
		}
		else {
			System.out.println("Wrong phone number format. Please try again!");
		}   
        this.property = property;
    }

    //Getters
    public String getAFM() { return this.AFM; }

    public String getPhoneNumber() { return this.phoneNumber; }

    public String getProperty() { return this.property;}

    //Setters

    public void setPhoneNumber(String phoneNumber) { 
    	if(Users.isTelValid(phoneNumber)) {
    		System.out.println("Setting phone number...Correct phone number format!");
    		this.phoneNumber = phoneNumber;
    	}else { System.out.println("Wrong phone number format. Please try again!");}
    }

    public void setProperty( String property) { 
    	System.out.println("Setting property...Property changed!");
    	this.property = property; }

    //Show bill
    public void ShowBill(String phoneNumber) { System.out.println("The bill for phone number: " + phoneNumber + " is: "); }

    //Show call log
    public void CallLog(String phoneNumber) { System.out.println("The call log for phone number: " + phoneNumber+ " is: "); }

    //Pay bill
    public void PayBill(String phoneNumber) { System.out.println("The bill for phone number: " + phoneNumber + " has been paid!"); }

    //Request plan change
    public void PlanChange(String afm, String phoneNumber, String property) {
        System.out.println("Customer with:\n " + "AFM: " + afm + "\n Phone number: " + phoneNumber + "\n Property: " + property + "\nrequested a change of plan."); }

    //Change password
    public void PasswordChange() { System.out.println("Changing password...Completed!");};
}
